# AS-IS Specification - Step 1 and Step 2

- **Owner:** <Member 2> | **Source:** process QTQL.NC2.3.1 | **Version:** 1.0 (Week 2)

## Step 1 - Initiation and multi-level signing

| Item | Description |
|---|---|
| Goal | Get permission to carry out the research topic at the hospital |
| Actors | Student, Supervisor, Head of Department/Center, QLDT, Board of Directors |
| Input | Research idea; BM1/QTQL.NC2.3.1 form (paper template) |
| Trigger | Student decides to do a research topic at the hospital |
| Output | BM1 with all signatures; original submitted to QLDT; student keeps a copy |
| Related rules | BR-01 (backup copy), BR-05 (legal basis) |

### Content of BM1
- Administrative: student name, course year, school/institute.
- Topic: expected title, objective, method, expected duration, study subject.
- Topic category (choose one): institutional-level; ministry/province level or S&T fund; clinical trial; new method/technique; none of the above.
- Signatures: Supervisor, Head of Department/Center, QLDT, Board of Directors.

### Current procedure
1. Student fills in BM1.
2. Supervisor reviews and signs.
3. Head of Department/Center signs to allow research at the unit.
4. QLDT is part of the signing chain and receives the file.
5. Board of Directors approves.
6. Student submits the original signed BM1 to QLDT.
7. Student photocopies/scans the signed BM1 before submitting the original, and uses the copy for later procedures.

### Exceptions
| Case | Current handling |
|---|---|
| A signer refuses | Student must revise BM1 and ask again |
| Student loses the copy | Must request a copy again from QLDT (not defined in the source) |

### Pain points (why a system helps)
- Paper moves physically between 4 offices; hard to know where BM1 is.
- No signing history; no reminder for the backup copy.

## Step 2 - Proposal defense

| Item | Description |
|---|---|
| Goal | Get the proposal approved by the training institution |
| Actors | Student, Training Institution (CSDT) |
| Input | Signed BM1 (copy), draft proposal |
| Trigger | BM1 approved and submitted to QLDT |
| Output | Proposal defense result and date |
| Related rules | None specific |

### Current procedure
1. Student registers and defends the proposal at the university.
2. The university issues the defense result.
3. The result and date are recorded for the hospital file.

### Exceptions
| Case | Current handling |
|---|---|
| Proposal not passed | Student revises and defends again (not detailed in source) |

### Data needed by the system
Defense date, institution name, result, related topic ID.
