# System Scope

- **Version:** 1.0 (Week 2) | **Owner:** <Member 5>

## 1. System purpose
Support the management of a student's scientific research topic from proposal (BM1) to closing and archiving (BM2), following process QTQL.NC2.3.1 of the National Children's Hospital, so that signing, status tracking and record retention are done electronically and traceably instead of by paper alone.

## 2. In-scope (the system supports)
| # | Capability | Related requirements |
|---|---|---|
| 1 | Electronic BM1 form and multi-level signing workflow (Supervisor -> Head -> QLDT -> BGD) | FR-01 to FR-06 |
| 2 | Tracking the topic status through the 6-step lifecycle | FR-07, FR-09, FR-10, FR-14 |
| 3 | Recording ethics review registration and result | FR-08 |
| 4 | BM2 receipt issuance and thesis soft-copy upload | FR-11, FR-12 |
| 5 | Archive record management (5 years, paper form, shredding disposal flag) | FR-13, NFR-07 |
| 6 | User accounts and role-based access | FR-15, NFR-01 |
| 7 | Audit trail of approvals and status changes | NFR-02 |

## 3. Out-of-scope (the system will NOT handle)
| # | Item | Reason |
|---|---|---|
| 1 | Scientific content review of the topic | Done by supervisor/council, not a system function |
| 2 | The university's own proposal/thesis defense procedure | Only the date and result are recorded |
| 3 | The ethics committee's internal scoring/deliberation | System only records registration and decision |
| 4 | Plagiarism check and thesis content evaluation | Not part of the hospital process |
| 5 | Physical shredding and physical storage logistics | System only flags records due for disposal |
| 6 | Integration with hospital HIS or university systems | Beyond course scope |

## 4. Scope of the team's work in this course
| Area | Level | Detail |
|---|---|---|
| Business process analysis | Full | Actors, artifacts, AS-IS 6 steps, business rules |
| Requirements | Full | FR/NFR with acceptance criteria |
| Modeling (UML) | Full | Use Case, Activity, State Machine, Class, Sequence |
| Database design | Full | ERD, data dictionary, SQL schema |
| Implementation | Core only | BM1 management, approval workflow, status tracking, BM2 receipt, archive record |
| Analysis only (not implemented) | - | Ethics committee internal workflow, email/SMS notification, external integration |

## 5. Assumptions
- Users are hospital staff and students who already know the paper process.
- One student has one active research topic at a time.
- BM1 approval order is fixed: Supervisor -> Head -> QLDT -> BGD.
- Retention starts at the closing date of the topic.

## 6. Constraints
- Must follow the hospital process QTQL.NC2.3.1 and the legal basis: Circular 37/2010/TT-BYT and Circular 14/2014/TT-BKHCN.
- Project duration: 14 weeks, team of 5.

## 7. System boundary summary
Inside the boundary: the web system, its database and uploaded files. Outside the boundary: the university, the ethics committee's internal process, paper archive room. Interaction with outside parties happens through people (QLDT staff or the student enter results such as defense outcomes).
