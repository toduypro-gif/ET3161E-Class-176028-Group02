# Business Rules

- **Owner:** <Member 5> | **Version:** 1.0 (Week 2)

## 1. Business rules from the process document

| ID | Rule | Source | Applies to | System implication |
|---|---|---|---|---|
| BR-01 | The student must photocopy/scan the fully signed BM1 before submitting the original to QLDT, and use the copy for later procedures | Process QTQL.NC2.3.1, Step 1 | Step 1 | Provide upload of the scan (FR-05) and a reminder when submitting |
| BR-02 | Proposal, thesis and BM2 records are retained for 5 years at QLDT | Records management section | Step 6 | Archive record with retentionYears = 5 (FR-13, NFR-07) |
| BR-03 | Records are retained as paper documents | Records management section | Step 6 | Storage form field = Paper; system references the physical record |
| BR-04 | After retention ends, records are destroyed by shredding | Records management section | Step 6 | Disposal method = Shredding; flag "due for disposal" |
| BR-05 | The process is based on Circular 37/2010/TT-BYT (MOH) and Circular 14/2014/TT-BKHCN (MOST) | Legal basis section | All | Cited in report; guides retention/registration rules |

## 2. Business rules derived from the process flow (to be confirmed with the instructor)

| ID | Rule | Reason | System implication |
|---|---|---|---|
| BR-06 | BM1 approval order is fixed: Supervisor -> Head of Dept./Center -> QLDT -> BGD | Order of signatures on BM1 | Workflow enforces order (FR-02, NFR-03) |
| BR-07 | A rejection at any level returns BM1 to the student | A refused signature means the form must be corrected | Status Rejected -> student revises (FR-03) |
| BR-08 | A topic can start implementation only after proposal defense and ethics approval | Step order 2 -> 3 -> 4 | Status In Progress only after ethics approval (FR-09) |
| BR-09 | A topic is Closed only after BM2 is issued | Step 6 ends with BM2 | Close and archive after receipt (FR-12, FR-13) |
| BR-10 | Topic category must be exactly one of five options | BM1 checkbox list | Dropdown with 5 values (FR-01) |

## 3. Assumptions to confirm
| # | Assumption | Question for instructor |
|---|---|---|
| A1 | Retention starts on the closing/archiving date | Correct starting point? |
| A2 | BR-01 is a reminder plus optional upload, not a blocking rule | Should submission be blocked without a scan? |
| A3 | One student has one active topic at a time | Can a student have several topics? |

## 4. Rule -> data mapping
| Rule | Table.field |
|---|---|
| BR-01 | ProposalForm_BM1.scanFilePath |
| BR-02 | ArchiveRecords.retentionYears (default 5) |
| BR-03 | ArchiveRecords.storageForm (default Paper) |
| BR-04 | ArchiveRecords.disposalMethod (default Shredding), disposalDueDate |
| BR-06/07 | Approvals.level, Approvals.decision |
| BR-08/09 | ResearchTopics.status |
| BR-10 | ResearchTopics.category |
