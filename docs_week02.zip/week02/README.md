# Week 02 documents

Requirement completion, system scope and AS-IS analysis (per instructor's notes).

| File | Content | Owner |
|---|---|---|
| requirements.md | FR/NFR with acceptance criteria and traceability | <Member 1> |
| scope.md | In/out-of-scope and team implementation scope | <Member 5> |
| actors.md | Actors and actor-function matrix | <Member 1> |
| as-is-step1-2.md | AS-IS Steps 1-2 | <Member 2> |
| as-is-step3-4.md | AS-IS Steps 3-4 | <Member 3> |
| as-is-step5-6.md | AS-IS Steps 5-6 | <Member 4> |
| business-rules.md | Business rules and assumptions | <Member 5> |
