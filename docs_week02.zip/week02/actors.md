# Actors (Users) and Their Functions

- **Version:** 1.0 (Week 2) | **Owner:** <Member 1>

## 1. Actor list
| Actor | Who exactly | Type | Main goal |
|---|---|---|---|
| Student (HV) | Master's / PhD / undergraduate student performing the research topic | Primary | Complete the topic lifecycle from BM1 to BM2 |
| Supervisor (GVHD) | Academic supervisor of the student | Primary | Review, sign and follow the student's topic |
| Head of Department / Center | Head of the unit where the research is carried out | Primary | Permit research at the unit |
| Training Management Office (QLDT) | Staff of the training management office | Primary | Receive records, track status, issue BM2, manage archive |
| Board of Directors (BGD) | Hospital leadership | Primary | Final approval of the proposal |
| Ethics Committee (HDDD) | Hospital ethics review council | Primary | Decide on ethical approval |
| Training Institution (CSDT) | University where the student studies | External | Holds proposal/thesis defenses (results entered into the system) |
| Administrator | System administrator | Support | Manage accounts and roles |

## 2. Actor - function matrix (C = create, R = read, U = update, A = approve/reject)
| Function | Student | Supervisor | Head | QLDT | BGD | Ethics | Admin |
|---|---|---|---|---|---|---|---|
| Create/edit BM1 (FR-01) | C,R,U | R | R | R | R | - | - |
| Submit BM1 for signing (FR-02) | U | - | - | - | - | - | - |
| Approve/reject BM1 (FR-03) | - | A | A | A | A | - | - |
| View signing history (FR-04) | R | R | R | R | R | - | - |
| Upload signed BM1 scan (FR-05) | C | - | - | R | - | - | - |
| Confirm receipt of original BM1 (FR-06) | R | - | - | U | - | - | - |
| Record proposal defense (FR-07) | C | - | - | C | - | - | - |
| Register/decide ethics review (FR-08) | C | - | - | R | - | A | - |
| Update progress (FR-09) | - | U | - | R | - | - | - |
| Record thesis defense (FR-10) | C | - | - | C | - | - | - |
| Submit thesis / confirm receipt (FR-11) | C | - | - | U | - | - | - |
| Issue BM2 receipt (FR-12) | R | - | - | C | - | - | - |
| Archive record (FR-13) | - | - | - | C,U | - | - | - |
| Search / dashboard (FR-14) | R | R | R | R | R | R | R |
| Manage accounts (FR-15) | - | - | - | - | - | - | C,U |

## 3. Actor descriptions
**Student** - starts the process by filling BM1, must keep a signed copy (BR-01), registers ethics review, tracks status, and at the end submits the soft copy and printed thesis.

**Supervisor** - first signer of BM1; may reject with comment; updates research progress after implementation starts.

**Head of Department/Center** - second signer; confirms the student may do the research at the unit.

**QLDT** - receives the original signed BM1, is part of the signing chain, records defense results, receives the final thesis, issues BM2, and manages the 5-year archive.

**BGD** - last approval level. After approval the student submits the signed original to QLDT.

**Ethics Committee** - reviews the ethics registration and records approval or rejection.

**Training Institution** - external; the system does not run its process but stores the defense date and result.

**Administrator** - creates accounts, assigns roles, disables users.
